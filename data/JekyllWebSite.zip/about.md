---
layout: default
---
# About

In 1918, my Great, Great Uncle - Herbert Holloway - wrote a journal of the first part of his life. There's about 350 pages of text, and about 35 images - Herbert's paintings, some photographs, newspaper clippings, and some music that Herbert wrote or liked playing.

This site is a work in progress!


