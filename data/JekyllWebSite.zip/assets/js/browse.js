document.addEventListener("DOMContentLoaded", () => {
  const query = new URLSearchParams(window.location.search);
  const raw = query.get("page");
  const page = parseInt(raw, 10);
  const pageNum = Number.isInteger(page) && page > 0 ? page : 1;

  const contentDiv = document.getElementById("journal-body");
  const backBtn = document.getElementById("nav-back");
  const nextBtn = document.getElementById("nav-next");
  const pageInput = document.getElementById("page-input");

  function loadPage(num) {
    const contentDiv = document.getElementById("journal-body");
    const backBtn = document.getElementById("nav-back");
    const nextBtn = document.getElementById("nav-next");
    const pageInput = document.getElementById("page-input");

    pageInput.value = num;
    document.getElementById("page-number").textContent = `Page ${num}`;

    // Load page HTML
    fetch(`/assets/build/pages/page_${num}.html`)
      .then(res => {
        if (!res.ok) {
          if (num === 1) {
            contentDiv.innerHTML = `<p>Page 1 not found.</p>`;
          } else {
            window.location.href = "?page=1";
          }
          throw new Error("Page not found");
        }
        return res.text();
      })
      .then(html => {
        contentDiv.innerHTML = html;

        // Try to load image
        const img = new Image();
        img.src = `/assets/journal/img/${num}.jpg`;
        img.alt = `Scan of page ${num}`;
        img.onload = () => contentDiv.appendChild(img);

        // ✅ Inject comments *after* HTML is loaded
        return fetch("/assets/build/data.json");
      })
      .then(res => res.json())
      .then(data => {
        const comments = data[num];
        if (!comments) return;

        for (const [id, text] of Object.entries(comments)) {
          const el = document.querySelector(`[data-comment-id="${id}"]`);
          el.classList.add("has-comment");
          el.addEventListener("click", e => {
            e.preventDefault();
            showCommentPopup(el, text);
          });
        }
      });

    // Back button
    if (num > 1) {
      backBtn.href = `?page=${num - 1}`;
      backBtn.style.display = "";
    } else {
      backBtn.style.display = "none";
    }

    // Next button
    const nextPage = num + 1;
    fetch(`/assets/build/pages/page_${nextPage}.html`, { method: "HEAD" })
      .then(res => {
        if (res.ok) {
          nextBtn.href = `?page=${nextPage}`;
          nextBtn.style.display = "";
        } else {
          nextBtn.style.display = "none";
        }
      })
      .catch(() => {
        nextBtn.style.display = "none";
      });
  }

  // Input box navigation
  pageInput.addEventListener("keydown", e => {
    if (e.key === "Enter") {
      const target = parseInt(pageInput.value.trim(), 10);
      if (Number.isInteger(target) && target > 0 && target <= 999) {
        window.location.href = `?page=${target}`;
      }
    }
  });

  loadPage(pageNum);

  // ← and → arrow key navigation
  document.addEventListener("keydown", e => {
    if (e.key === "ArrowLeft" && backBtn.style.display !== "none") {
      window.location.href = backBtn.href;
    } else if (e.key === "ArrowRight" && nextBtn.style.display !== "none") {
      window.location.href = nextBtn.href;
    }
  });

});

// swipe nav
let touchStartX = 0;
let touchEndX = 0;

function handleSwipe() {
  const threshold = 50; // min distance in px
  const dx = touchEndX - touchStartX;
  if (Math.abs(dx) > threshold) {
    if (dx > 0 && backBtn.style.display !== "none") {
      window.location.href = backBtn.href;
    } else if (dx < 0 && nextBtn.style.display !== "none") {
      window.location.href = nextBtn.href;
    }
  }
}

document.addEventListener("touchstart", e => {
  touchStartX = e.changedTouches[0].screenX;
});

document.addEventListener("touchend", e => {
  touchEndX = e.changedTouches[0].screenX;
  handleSwipe();
});


// inline comment pop ups
function showCommentPopup(anchorEl, htmlContent) {
  let popup = document.getElementById("comment-popup");
  if (!popup) {
    popup = document.createElement("div");
    popup.id = "comment-popup";
    popup.innerHTML = `<div class="popup-content"></div><button id="popup-close">×</button>`;
    document.body.appendChild(popup);
    document.getElementById("popup-close").addEventListener("click", () => {
      popup.style.display = "none";
    });
  }

  popup.querySelector(".popup-content").innerHTML = linkify(htmlContent);
  popup.style.display = "block";

  // Position near anchor
  const rect = anchorEl.getBoundingClientRect();
  popup.style.top = `${rect.bottom + window.scrollY + 8}px`;
  popup.style.left = `${rect.left + window.scrollX}px`;
}

function linkify(text) {
  const urlRegex = /(https?:\/\/[^\s]+)/g;
  return text.replace(urlRegex, url => {
    const safeURL = url.replace(/"/g, '&quot;');
    return `<a href="${safeURL}" target="_blank" rel="noopener noreferrer">${url}</a>`;
  });
}

document.addEventListener("click", e => {
  const popup = document.getElementById("comment-popup");

  if (
    popup &&
    popup.style.display === "block" &&
    !popup.contains(e.target) &&
    !e.target.classList.contains("has-comment")
  ) {
    popup.style.display = "none";
  }
});

document.addEventListener("keydown", e => {
  if (e.key === "Escape") {
    const popup = document.getElementById("comment-popup");
    if (popup) popup.style.display = "none";
  }
});



function handleSwipe() {
  const deltaX = touchEndX - touchStartX;
  if (Math.abs(deltaX) < 50) return; // ignore short swipes

  if (deltaX > 0) {
    // swipe right = back
    document.getElementById("nav-back")?.click();
  } else {
    // swipe left = next
    document.getElementById("nav-next")?.click();
  }
}
